Running netgen.tcl will generate the netlist named xge_mac_wrapper.edf. This netlist can be used as the MAC core in 10GbE CLIP.

Steps:

1. Open Vivado by:
CMD>C:\NIFPGA\programs\Vivado2014_4\bin\vivado.bat

2. Use TCL command:
source ./netgen.tcl
